# Proposed branch: `bumani-w2s-model`

This patch is designed to be applied to `Elhadjzz/BUMANI-Climate-Voice` on a separate branch named `bumani-w2s-model`. It does not replace the existing FastAPI/NLLB/MMS application.

## What this adds

- a real daily climate-data acquisition pipeline using the public NASA POWER API;
- spatial sampling across the complete polygons of Mali, Burkina Faso and Niger;
- Week-1 through Week-6 (42-day) rainfall prediction targets;
- chronological train/validation/test splitting;
- climatology and persistence baselines;
- HistGradientBoosting and XGBoost models;
- country-level and lead-time evaluation;
- automatic BUMANI_CIC terminology auditing;
- GitHub Actions execution and artifact export.

## Scientific caution

NASA POWER is used as the first fully reproducible, no-login empirical baseline. The paper should describe it as the baseline dataset, not as CHIRPS/ERA5. CHIRPS, AIFS and FengWu-W2S should be added as independent rainfall verification and AI forecast benchmarks once their retrieval paths are run successfully. Do not claim FengWu-W2S results before a real FengWu-W2S forecast archive/checkpoint has been executed.
