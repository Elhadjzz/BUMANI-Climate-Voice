param(
    [string]$RepoUrl = "https://github.com/Elhadjzz/BUMANI-Climate-Voice.git",
    [string]$Branch = "bumani-w2s-model"
)

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$WorkDir = Join-Path $env:TEMP "BUMANI-Climate-Voice-w2s"

Write-Host "BUMANI-W2S branch installer" -ForegroundColor Cyan

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw "Git is not installed or not available in PATH. Install Git for Windows or use GitHub Desktop."
}

if (Test-Path $WorkDir) {
    Remove-Item -Recurse -Force $WorkDir
}

Write-Host "Cloning repository..."
git clone $RepoUrl $WorkDir
if ($LASTEXITCODE -ne 0) { throw "git clone failed." }

Set-Location $WorkDir

Write-Host "Checking out branch $Branch..."
git fetch origin
git checkout $Branch
if ($LASTEXITCODE -ne 0) { throw "Could not checkout $Branch. Confirm the branch exists on GitHub." }

New-Item -ItemType Directory -Force -Path "climate_model" | Out-Null
New-Item -ItemType Directory -Force -Path ".github\workflows" | Out-Null

Copy-Item -Recurse -Force (Join-Path $PackageRoot "climate_model\*") "climate_model\"
Copy-Item -Force (Join-Path $PackageRoot ".github\workflows\bumani-climate-model.yml") ".github\workflows\bumani-climate-model.yml"
Copy-Item -Force (Join-Path $PackageRoot "BRANCH_README.md") "BUMANI_W2S_BRANCH_README.md"

Write-Host "Files copied. Committing..."
git add climate_model .github/workflows/bumani-climate-model.yml BUMANI_W2S_BRANCH_README.md
git status --short

git commit -m "Add BUMANI-W2S empirical climate modelling workflow"
if ($LASTEXITCODE -ne 0) {
    Write-Host "Nothing new to commit, or git user identity may need configuration." -ForegroundColor Yellow
}

Write-Host "Pushing branch..."
git push origin $Branch
if ($LASTEXITCODE -ne 0) { throw "git push failed. Sign in to GitHub when prompted and run the script again." }

Write-Host ""
Write-Host "SUCCESS: BUMANI-W2S files were pushed to $Branch." -ForegroundColor Green
Write-Host "Next: open GitHub > Actions > BUMANI-W2S empirical climate model."
