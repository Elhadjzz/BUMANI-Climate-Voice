# BUMANI-W2S empirical climate model

This directory contains the empirical modelling layer for BUMANI Climate Voice. It is intentionally separate from the production translation/TTS backend.

## Scientific task

The model predicts seven-day accumulated rainfall for six lead windows:

- Week 1: days 1-7
- Week 2: days 8-14
- Week 3: days 15-21
- Week 4: days 22-28
- Week 5: days 29-35
- Week 6: days 36-42

Spatial coverage is obtained by sampling a regular grid across the full national polygons of Mali, Burkina Faso and Niger. The default grid spacing is 1.5 degrees. Daily predictors come from NASA POWER and include precipitation, temperature, humidity, wind and solar radiation. The modelling code is structured so CHIRPS/AIFS/FengWu-W2S can be added as benchmark or forecast inputs without changing the evaluation layer.

## Models

The workflow evaluates:

1. seasonal climatology baseline;
2. persistence baseline;
3. HistGradientBoostingRegressor;
4. XGBoost.

Data are split chronologically:

- training: 1998-2018
- validation: 2019-2022
- independent test: 2023-2025

## Outputs

`results/` contains:

- `metrics.csv`
- `country_metrics.csv`
- `predictions_test.csv.gz`
- `grid_points.csv`
- `bumani_terminology_audit.csv`
- `results_summary.md`
- PNG figures
- trained model files

## Run locally

```bash
pip install -r climate_model/requirements.txt
python climate_model/run_experiment.py
```

For an offline integrity check that does not download external data:

```bash
python climate_model/run_experiment.py --synthetic-smoke-test
```
