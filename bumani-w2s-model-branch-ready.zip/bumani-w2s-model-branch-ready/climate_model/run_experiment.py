from __future__ import annotations

import argparse
import gzip
import io
import json
import math
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests
from shapely.geometry import Point, shape
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor

ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "climate_model"
RAW_DIR = MODEL_DIR / "data" / "raw"
PROCESSED_DIR = MODEL_DIR / "data" / "processed"
RESULTS_DIR = ROOT / "results"
MODELS_DIR = RESULTS_DIR / "models"

POWER_URL = "https://power.larc.nasa.gov/api/temporal/daily/point"
BOUNDARY_URL = "https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson"

COUNTRIES = {
    "Mali": {"iso3": "MLI", "bbox": (-12.3, 10.0, 4.3, 25.1)},
    "Burkina Faso": {"iso3": "BFA", "bbox": (-5.6, 9.3, 2.5, 15.1)},
    "Niger": {"iso3": "NER", "bbox": (0.1, 11.6, 16.0, 23.6)},
}

POWER_PARAMETERS = [
    "PRECTOTCORR",
    "T2M",
    "T2M_MAX",
    "T2M_MIN",
    "RH2M",
    "WS10M",
    "ALLSKY_SFC_SW_DWN",
]

WEEK_WINDOWS = {
    "week1": (1, 7),
    "week2": (8, 14),
    "week3": (15, 21),
    "week4": (22, 28),
    "week5": (29, 35),
    "week6": (36, 42),
}

FEATURES = [
    "lat",
    "lon",
    "country_code",
    "doy_sin",
    "doy_cos",
    "month_sin",
    "month_cos",
    "PRECTOTCORR",
    "precip_lag1",
    "precip_lag2",
    "precip_lag3",
    "precip_lag7",
    "precip_roll7",
    "precip_roll14",
    "T2M",
    "T2M_roll7",
    "T2M_MAX",
    "T2M_MIN",
    "RH2M",
    "RH2M_roll7",
    "WS10M",
    "ALLSKY_SFC_SW_DWN",
]


def ensure_dirs() -> None:
    for p in [RAW_DIR, PROCESSED_DIR, RESULTS_DIR, MODELS_DIR]:
        p.mkdir(parents=True, exist_ok=True)


def request_with_retries(url: str, *, params: dict | None = None, timeout: int = 180, tries: int = 6) -> requests.Response:
    last = None
    for attempt in range(tries):
        try:
            r = requests.get(url, params=params, timeout=timeout, headers={"User-Agent": "BUMANI-W2S-research/1.0"})
            if r.status_code == 429:
                time.sleep(min(90, 5 * (2 ** attempt)))
                last = RuntimeError("NASA POWER rate limited request")
                continue
            r.raise_for_status()
            return r
        except Exception as exc:
            last = exc
            time.sleep(min(60, 2 * (2 ** attempt)))
    raise RuntimeError(f"Request failed after {tries} attempts: {last}")


def load_country_geometries() -> Dict[str, object]:
    cache = RAW_DIR / "countries.geojson"
    if not cache.exists():
        r = request_with_retries(BOUNDARY_URL, timeout=120)
        cache.write_bytes(r.content)
    data = json.loads(cache.read_text(encoding="utf-8"))
    out = {}
    for feat in data["features"]:
        props = feat.get("properties", {})
        name = props.get("ADMIN") or props.get("name") or props.get("NAME")
        iso = props.get("ISO_A3") or props.get("ISO3") or props.get("iso_a3")
        for target, meta in COUNTRIES.items():
            if name == target or iso == meta["iso3"]:
                out[target] = shape(feat["geometry"])
    missing = sorted(set(COUNTRIES) - set(out))
    if missing:
        raise RuntimeError(f"Country polygons not found in boundary source: {missing}")
    return out


def make_grid_points(step: float) -> pd.DataFrame:
    geoms = load_country_geometries()
    rows = []
    for country, meta in COUNTRIES.items():
        minx, miny, maxx, maxy = meta["bbox"]
        xs = np.arange(math.floor(minx / step) * step, maxx + step * 0.5, step)
        ys = np.arange(math.floor(miny / step) * step, maxy + step * 0.5, step)
        geom = geoms[country]
        for lat in ys:
            for lon in xs:
                p = Point(float(lon), float(lat))
                if geom.covers(p):
                    rows.append({"country": country, "lat": round(float(lat), 4), "lon": round(float(lon), 4)})
    df = pd.DataFrame(rows).drop_duplicates().reset_index(drop=True)
    if len(df) < 20:
        raise RuntimeError(f"Too few spatial sample points generated: {len(df)}")
    df["grid_id"] = [f"g{i:04d}" for i in range(len(df))]
    df.to_csv(RESULTS_DIR / "grid_points.csv", index=False)
    return df


def parse_power_payload(payload: dict, country: str, lat: float, lon: float, grid_id: str) -> pd.DataFrame:
    params = payload.get("properties", {}).get("parameter", {})
    if not params:
        raise ValueError("NASA POWER payload contains no properties.parameter data")
    dates = sorted(set().union(*(v.keys() for v in params.values() if isinstance(v, dict))))
    rows = []
    for date_key in dates:
        if not re.fullmatch(r"\d{8}", str(date_key)):
            continue
        row = {"date": pd.to_datetime(str(date_key), format="%Y%m%d"), "country": country, "lat": lat, "lon": lon, "grid_id": grid_id}
        for name in POWER_PARAMETERS:
            val = params.get(name, {}).get(str(date_key), np.nan)
            try:
                val = float(val)
                if val <= -900:
                    val = np.nan
            except Exception:
                val = np.nan
            row[name] = val
        rows.append(row)
    if not rows:
        raise ValueError("No daily records parsed from NASA POWER response")
    return pd.DataFrame(rows)


def download_one_point(rec: dict, start: str, end: str) -> pd.DataFrame:
    cache = RAW_DIR / f"power_{rec['grid_id']}_{start}_{end}.json.gz"
    if cache.exists():
        with gzip.open(cache, "rt", encoding="utf-8") as f:
            payload = json.load(f)
    else:
        params = {
            "parameters": ",".join(POWER_PARAMETERS),
            "community": "AG",
            "longitude": rec["lon"],
            "latitude": rec["lat"],
            "start": start.replace("-", "")[:8],
            "end": end.replace("-", "")[:8],
            "format": "JSON",
            "time-standard": "UTC",
        }
        payload = request_with_retries(POWER_URL, params=params).json()
        with gzip.open(cache, "wt", encoding="utf-8") as f:
            json.dump(payload, f)
        time.sleep(0.15)
    return parse_power_payload(payload, rec["country"], rec["lat"], rec["lon"], rec["grid_id"])


def download_power_grid(grid: pd.DataFrame, start: str, end: str, workers: int) -> pd.DataFrame:
    records = grid.to_dict("records")
    frames: List[pd.DataFrame] = []
    errors = []
    with ThreadPoolExecutor(max_workers=max(1, min(workers, 5))) as ex:
        futures = {ex.submit(download_one_point, rec, start, end): rec for rec in records}
        for i, fut in enumerate(as_completed(futures), 1):
            rec = futures[fut]
            try:
                frames.append(fut.result())
            except Exception as exc:
                errors.append((rec, str(exc)))
                print(f"WARNING: failed {rec['grid_id']} {rec['country']} ({rec['lat']},{rec['lon']}): {exc}", file=sys.stderr)
            if i % 10 == 0 or i == len(records):
                print(f"Downloaded/processed {i}/{len(records)} grid points; successful={len(frames)}")
    if len(frames) < max(10, int(0.8 * len(records))):
        raise RuntimeError(f"Insufficient successful NASA POWER grid points ({len(frames)}/{len(records)}). Errors sample: {errors[:5]}")
    df = pd.concat(frames, ignore_index=True)
    df = df.sort_values(["grid_id", "date"]).reset_index(drop=True)
    df.to_csv(PROCESSED_DIR / "power_daily.csv.gz", index=False, compression="gzip")
    return df


def synthetic_data(grid_step: float = 3.0) -> pd.DataFrame:
    rng = np.random.default_rng(42)
    # Synthetic points are only for code integrity testing, never scientific results.
    countries = [("Mali", 12.0, -8.0), ("Burkina Faso", 12.0, -2.0), ("Niger", 14.0, 4.0)]
    dates = pd.date_range("2015-01-01", "2025-12-31", freq="D")
    frames = []
    for j, (country, lat0, lon0) in enumerate(countries):
        for k in range(4):
            lat = lat0 + 0.7 * k
            lon = lon0 + 0.6 * k
            doy = dates.dayofyear.to_numpy()
            seasonal_rain = np.maximum(0, 5 + 5 * np.sin((doy - 150) * 2 * np.pi / 365.25))
            wet = rng.random(len(dates)) < (seasonal_rain / 20).clip(0.02, 0.55)
            precip = wet * rng.gamma(1.8, np.maximum(seasonal_rain, 0.5))
            temp = 30 + 5 * np.sin((doy - 40) * 2 * np.pi / 365.25) + rng.normal(0, 1.5, len(dates))
            rh = 35 + 30 * np.sin((doy - 150) * 2 * np.pi / 365.25) + rng.normal(0, 5, len(dates))
            frames.append(pd.DataFrame({
                "date": dates,
                "country": country,
                "lat": lat,
                "lon": lon,
                "grid_id": f"s{j}{k}",
                "PRECTOTCORR": precip,
                "T2M": temp,
                "T2M_MAX": temp + 5 + rng.normal(0, 0.5, len(dates)),
                "T2M_MIN": temp - 5 + rng.normal(0, 0.5, len(dates)),
                "RH2M": np.clip(rh, 5, 100),
                "WS10M": np.clip(rng.normal(3, 0.8, len(dates)), 0, None),
                "ALLSKY_SFC_SW_DWN": np.clip(rng.normal(20, 4, len(dates)), 0, None),
            }))
    return pd.concat(frames, ignore_index=True)


def future_sum(s: pd.Series, start_day: int, end_day: int) -> pd.Series:
    out = pd.Series(0.0, index=s.index)
    valid = pd.Series(True, index=s.index)
    for k in range(start_day, end_day + 1):
        shifted = s.shift(-k)
        out = out + shifted.fillna(0)
        valid &= shifted.notna()
    return out.where(valid)


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy().sort_values(["grid_id", "date"]).reset_index(drop=True)
    country_map = {c: i for i, c in enumerate(COUNTRIES)}
    df["country_code"] = df["country"].map(country_map).astype(float)
    doy = df["date"].dt.dayofyear
    month = df["date"].dt.month
    df["doy_sin"] = np.sin(2 * np.pi * doy / 365.25)
    df["doy_cos"] = np.cos(2 * np.pi * doy / 365.25)
    df["month_sin"] = np.sin(2 * np.pi * month / 12)
    df["month_cos"] = np.cos(2 * np.pi * month / 12)

    grouped = df.groupby("grid_id", group_keys=False)
    for lag in [1, 2, 3, 7]:
        df[f"precip_lag{lag}"] = grouped["PRECTOTCORR"].shift(lag)
    df["precip_roll7"] = grouped["PRECTOTCORR"].transform(lambda s: s.rolling(7, min_periods=5).sum())
    df["precip_roll14"] = grouped["PRECTOTCORR"].transform(lambda s: s.rolling(14, min_periods=10).sum())
    df["T2M_roll7"] = grouped["T2M"].transform(lambda s: s.rolling(7, min_periods=5).mean())
    df["RH2M_roll7"] = grouped["RH2M"].transform(lambda s: s.rolling(7, min_periods=5).mean())
    df["persistence_7d"] = grouped["PRECTOTCORR"].transform(lambda s: s.rolling(7, min_periods=7).sum())

    for label, (start_day, end_day) in WEEK_WINDOWS.items():
        df[f"target_{label}"] = grouped["PRECTOTCORR"].transform(lambda s, a=start_day, b=end_day: future_sum(s, a, b))

    return df


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    y_true = np.asarray(y_true)[mask]
    y_pred = np.asarray(y_pred)[mask]
    if len(y_true) == 0:
        return {"n": 0, "rmse": np.nan, "mae": np.nan, "r2": np.nan, "bias": np.nan}
    return {
        "n": int(len(y_true)),
        "rmse": float(mean_squared_error(y_true, y_pred) ** 0.5),
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "r2": float(r2_score(y_true, y_pred)) if len(y_true) > 1 else np.nan,
        "bias": float(np.mean(y_pred - y_true)),
    }


def add_climatology_predictions(train: pd.DataFrame, frame: pd.DataFrame, target: str) -> np.ndarray:
    # Seasonal climatology by country, calendar month and target horizon.
    climat = train.assign(month=train["date"].dt.month).groupby(["country", "month"])[target].mean()
    global_mean = float(train[target].mean())
    vals = []
    for row in frame[["country", "date"]].itertuples(index=False):
        vals.append(climat.get((row.country, row.date.month), global_mean))
    return np.asarray(vals, dtype=float)


def fit_and_evaluate(features: pd.DataFrame, sample_every: int = 3, smoke: bool = False) -> Tuple[pd.DataFrame, pd.DataFrame]:
    work = features.iloc[::max(1, sample_every)].copy()
    train = work[work["date"] <= "2018-12-31"].copy()
    val = work[(work["date"] >= "2019-01-01") & (work["date"] <= "2022-12-31")].copy()
    test = work[(work["date"] >= "2023-01-01") & (work["date"] <= "2025-12-31")].copy()

    # Synthetic smoke data begins in 2015; use adapted chronological split.
    if smoke:
        train = work[work["date"] <= "2020-12-31"].copy()
        val = work[(work["date"] >= "2021-01-01") & (work["date"] <= "2022-12-31")].copy()
        test = work[(work["date"] >= "2023-01-01") & (work["date"] <= "2025-12-31")].copy()

    if min(len(train), len(val), len(test)) == 0:
        raise RuntimeError(f"Chronological split failed: train={len(train)}, val={len(val)}, test={len(test)}")

    metrics_rows = []
    prediction_frames = []

    for horizon, _window in WEEK_WINDOWS.items():
        target = f"target_{horizon}"
        needed = FEATURES + [target, "persistence_7d"]
        tr = train.dropna(subset=needed).copy()
        va = val.dropna(subset=needed).copy()
        te = test.dropna(subset=needed).copy()
        if min(len(tr), len(va), len(te)) < 100:
            print(f"Skipping {horizon}; insufficient complete rows", file=sys.stderr)
            continue

        Xtr, ytr = tr[FEATURES], tr[target]
        Xva, yva = va[FEATURES], va[target]
        Xte, yte = te[FEATURES], te[target]

        baselines = {
            "climatology": add_climatology_predictions(tr, te, target),
            "persistence": te["persistence_7d"].to_numpy(dtype=float),
        }

        models = {
            "hist_gradient_boosting": HistGradientBoostingRegressor(
                learning_rate=0.06,
                max_iter=220 if not smoke else 40,
                max_leaf_nodes=31,
                l2_regularization=0.5,
                random_state=42,
            ),
            "xgboost": XGBRegressor(
                n_estimators=350 if not smoke else 50,
                max_depth=7,
                learning_rate=0.04,
                subsample=0.8,
                colsample_bytree=0.9,
                objective="reg:squarederror",
                tree_method="hist",
                n_jobs=4,
                random_state=42,
            ),
        }

        for name, pred in baselines.items():
            m = regression_metrics(yte.to_numpy(), pred)
            metrics_rows.append({"horizon": horizon, "model": name, "split": "test", **m})

        for name, model in models.items():
            print(f"Training {name} for {horizon}: n={len(tr):,}")
            model.fit(Xtr, ytr)
            pred_val = model.predict(Xva)
            pred_test = model.predict(Xte)
            metrics_rows.append({"horizon": horizon, "model": name, "split": "validation", **regression_metrics(yva.to_numpy(), pred_val)})
            metrics_rows.append({"horizon": horizon, "model": name, "split": "test", **regression_metrics(yte.to_numpy(), pred_test)})
            joblib.dump(model, MODELS_DIR / f"{name}_{horizon}.joblib")

            pf = te[["date", "country", "lat", "lon", "grid_id", target]].copy()
            pf = pf.rename(columns={target: "observed_rain_mm"})
            pf["predicted_rain_mm"] = pred_test
            pf["model"] = name
            pf["horizon"] = horizon
            prediction_frames.append(pf)

    metrics = pd.DataFrame(metrics_rows)
    predictions = pd.concat(prediction_frames, ignore_index=True) if prediction_frames else pd.DataFrame()
    metrics.to_csv(RESULTS_DIR / "metrics.csv", index=False)
    if not predictions.empty:
        predictions.to_csv(RESULTS_DIR / "predictions_test.csv.gz", index=False, compression="gzip")
    return metrics, predictions


def country_metrics(predictions: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if predictions.empty:
        return pd.DataFrame()
    for (country, horizon, model), g in predictions.groupby(["country", "horizon", "model"]):
        rows.append({"country": country, "horizon": horizon, "model": model, **regression_metrics(g["observed_rain_mm"].to_numpy(), g["predicted_rain_mm"].to_numpy())})
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS_DIR / "country_metrics.csv", index=False)
    return out


def plot_metrics(metrics: pd.DataFrame, country_df: pd.DataFrame) -> None:
    if metrics.empty:
        return
    order = list(WEEK_WINDOWS)
    test = metrics[metrics["split"] == "test"].copy()
    for metric in ["rmse", "mae", "r2"]:
        plt.figure(figsize=(8, 5))
        for model, g in test.groupby("model"):
            g = g.set_index("horizon").reindex(order)
            plt.plot(range(1, 7), g[metric], marker="o", label=model)
        plt.xticks(range(1, 7), ["W1", "W2", "W3", "W4", "W5", "W6"])
        plt.xlabel("Forecast window")
        plt.ylabel(metric.upper())
        plt.title(f"BUMANI-W2S rainfall {metric.upper()} by forecast window")
        plt.legend()
        plt.grid(alpha=0.25)
        plt.tight_layout()
        plt.savefig(RESULTS_DIR / f"{metric}_by_horizon.png", dpi=180)
        plt.close()

    if not country_df.empty:
        best_model = "xgboost" if (country_df["model"] == "xgboost").any() else country_df["model"].iloc[0]
        g = country_df[(country_df["model"] == best_model) & (country_df["horizon"] == "week2")]
        if not g.empty:
            plt.figure(figsize=(7, 4.5))
            plt.bar(g["country"], g["rmse"])
            plt.ylabel("RMSE (mm / 7-day window)")
            plt.title(f"{best_model}: Week-2 rainfall error by country")
            plt.xticks(rotation=15)
            plt.tight_layout()
            plt.savefig(RESULTS_DIR / "country_week2_rmse.png", dpi=180)
            plt.close()


def terminology_audit() -> pd.DataFrame:
    keywords = ["rain", "rainfall", "precip", "temperature", "heat", "drought", "dry", "flood", "humidity", "wind", "forecast", "warning", "climate"]
    files = {
        "bambara": ROOT / "BUMANI_CIC" / "english_bambara.csv",
        "hausa": ROOT / "BUMANI_CIC" / "english_hausa.csv",
        "moore": ROOT / "BUMANI_CIC" / "english_moore.csv",
    }
    frames = []
    for lang, path in files.items():
        if not path.exists():
            continue
        df = pd.read_csv(path)
        target_col = [c for c in df.columns if c.lower() != "english"][0]
        mask = df["english"].astype(str).str.lower().apply(lambda s: any(k in s for k in keywords))
        subset = df.loc[mask, ["english", target_col]].copy()
        subset = subset.rename(columns={target_col: "translation"})
        subset["language"] = lang
        frames.append(subset)
    out = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=["english", "translation", "language"])
    out.to_csv(RESULTS_DIR / "bumani_terminology_audit.csv", index=False)
    return out


def write_summary(metrics: pd.DataFrame, country_df: pd.DataFrame, terms: pd.DataFrame, smoke: bool) -> None:
    path = RESULTS_DIR / "results_summary.md"
    lines = ["# BUMANI-W2S empirical modelling results", ""]
    if smoke:
        lines.append("**IMPORTANT:** These results come from the synthetic smoke test and are NOT scientific findings.")
        lines.append("")
    else:
        lines.append("Data source: NASA POWER daily analysis-ready meteorological data sampled across the full national polygons of Mali, Burkina Faso and Niger.")
        lines.append("")
    if not metrics.empty:
        test = metrics[metrics["split"] == "test"].copy()
        if not test.empty:
            lines.append("## Test metrics")
            lines.append("")
            lines.append("```text")
            lines.append(test.sort_values(["horizon", "rmse"]).to_string(index=False))
            lines.append("```")
            lines.append("")
            xgb = test[test["model"] == "xgboost"]
            if not xgb.empty:
                best = xgb.sort_values("rmse").iloc[0]
                lines.append(f"Best XGBoost horizon by RMSE: **{best['horizon']}**, RMSE={best['rmse']:.3f} mm, MAE={best['mae']:.3f} mm, R²={best['r2']:.3f}.")
                lines.append("")
    if not country_df.empty:
        lines.append("## Country-level metrics")
        lines.append("")
        lines.append("```text")
        lines.append(country_df.sort_values(["country", "horizon", "model"]).to_string(index=False))
        lines.append("```")
        lines.append("")
    lines.append("## BUMANI terminology audit")
    lines.append("")
    lines.append(f"Climate/advisory terminology records found across the three BUMANI_CIC files: **{len(terms)}**.")
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", default="1998-01-01")
    parser.add_argument("--end", default="2025-12-31")
    parser.add_argument("--grid-step", type=float, default=1.5, help="Spatial sampling step in degrees across complete country polygons")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--sample-every", type=int, default=3, help="Use every Nth daily row for model fitting to keep CI runtime bounded")
    parser.add_argument("--synthetic-smoke-test", action="store_true")
    args = parser.parse_args()

    ensure_dirs()
    terms = terminology_audit()

    if args.synthetic_smoke_test:
        print("Running synthetic smoke test. Results are not scientific.")
        raw = synthetic_data()
        smoke = True
    else:
        grid = make_grid_points(args.grid_step)
        print(f"Spatial grid contains {len(grid)} points across Mali, Burkina Faso and Niger")
        raw = download_power_grid(grid, args.start, args.end, args.workers)
        smoke = False

    feat = engineer_features(raw)
    feat.to_csv(PROCESSED_DIR / ("features_smoke.csv.gz" if smoke else "features.csv.gz"), index=False, compression="gzip")
    metrics, predictions = fit_and_evaluate(feat, sample_every=args.sample_every, smoke=smoke)
    cmetrics = country_metrics(predictions)
    plot_metrics(metrics, cmetrics)
    write_summary(metrics, cmetrics, terms, smoke)
    print(f"Completed. Results written to {RESULTS_DIR}")


if __name__ == "__main__":
    main()
